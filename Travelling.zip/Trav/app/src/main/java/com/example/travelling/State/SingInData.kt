package com.example.travelling.State


data class SignInDateClass(
    val email: String = "",
    val password: String = "",
)